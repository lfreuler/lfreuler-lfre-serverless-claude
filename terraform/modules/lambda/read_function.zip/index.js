exports.handler = async (event) => {
  const AWS = require('aws-sdk');
  const documentClient = new AWS.DynamoDB.DocumentClient();
  const tableName = process.env.DYNAMODB_TABLE;

  try {
    // Handle different HTTP methods
    if (event.httpMethod === 'GET') {
      // If id is provided, get specific item
      if (event.queryStringParameters && event.queryStringParameters.id) {
        const id = event.queryStringParameters.id;

        // Query DynamoDB for items with the given ID, sorted by timestamp
        const params = {
          TableName: tableName,
          KeyConditionExpression: 'id = :id',
          ExpressionAttributeValues: {
            ':id': id
          },
          ScanIndexForward: false // Sort by timestamp in descending order
        };

        const result = await documentClient.query(params).promise();
        
        return {
          statusCode: 200,
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(result.Items)
        };
      } 
      // Otherwise, scan for all items (with pagination support)
      else {
        const params = {
          TableName: tableName,
          Limit: 50
        };

        // Support pagination with LastEvaluatedKey
        if (event.queryStringParameters && event.queryStringParameters.nextToken) {
          params.ExclusiveStartKey = JSON.parse(decodeURIComponent(event.queryStringParameters.nextToken));
        }

        const result = await documentClient.scan(params).promise();
        
        // Prepare response with pagination token if available
        const response = {
          items: result.Items,
          count: result.Count
        };
        
        if (result.LastEvaluatedKey) {
          response.nextToken = encodeURIComponent(JSON.stringify(result.LastEvaluatedKey));
        }

        return {
          statusCode: 200,
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(response)
        };
      }
    }

    // If not a GET request
    return {
      statusCode: 405,
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  } catch (error) {
    console.error('Error:', error);
    
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ error: 'Internal server error' })
    };
  }
};
