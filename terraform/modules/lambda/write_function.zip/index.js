exports.handler = async (event) => {
  const AWS = require('aws-sdk');
  const documentClient = new AWS.DynamoDB.DocumentClient();
  const tableName = process.env.DYNAMODB_TABLE;

  try {
    // Parse the request body
    let body;
    try {
      body = JSON.parse(event.body);
    } catch (e) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ error: 'Invalid request body' })
      };
    }

    // Validate the request body
    if (!body.id || !body.data) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ error: 'Missing required fields: id and data' })
      };
    }

    // Handle different HTTP methods
    if (event.httpMethod === 'POST' || event.httpMethod === 'PUT') {
      // Generate timestamp
      const timestamp = new Date().toISOString();

      // Prepare the item for DynamoDB
      const item = {
        id: body.id,
        timestamp: timestamp,
        data: body.data
      };

      // Write to DynamoDB
      const params = {
        TableName: tableName,
        Item: item
      };

      await documentClient.put(params).promise();

      return {
        statusCode: 201,
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(item)
      };
    } 
    else if (event.httpMethod === 'DELETE') {
      // For DELETE, we need both id and timestamp
      if (!event.pathParameters || !event.pathParameters.id) {
        return {
          statusCode: 400,
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ error: 'Missing id parameter' })
        };
      }

      const id = event.pathParameters.id;
      
      // If timestamp is provided in the query string parameters, delete specific item
      if (event.queryStringParameters && event.queryStringParameters.timestamp) {
        const timestamp = event.queryStringParameters.timestamp;

        const params = {
          TableName: tableName,
          Key: {
            id: id,
            timestamp: timestamp
          }
        };

        await documentClient.delete(params).promise();

        return {
          statusCode: 200,
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ message: 'Item deleted successfully' })
        };
      } 
      // Otherwise, query for all items with the given ID and delete them
      else {
        // First, query all items with the given ID
        const queryParams = {
          TableName: tableName,
          KeyConditionExpression: 'id = :id',
          ExpressionAttributeValues: {
            ':id': id
          }
        };

        const result = await documentClient.query(queryParams).promise();

        // If no items found, return 404
        if (result.Items.length === 0) {
          return {
            statusCode: 404,
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({ error: 'Item not found' })
          };
        }

        // Delete each item
        const deletePromises = result.Items.map(item => {
          const deleteParams = {
            TableName: tableName,
            Key: {
              id: item.id,
              timestamp: item.timestamp
            }
          };

          return documentClient.delete(deleteParams).promise();
        });

        await Promise.all(deletePromises);

        return {
          statusCode: 200,
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ message: 'Deleted items successfully' })
        };
      }
    }

    // If not a supported method
    return {
      statusCode: 405,
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  } catch (error) {
    console.error('Error:', error);
    
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ error: 'Internal server error' })
    };
  }
};
